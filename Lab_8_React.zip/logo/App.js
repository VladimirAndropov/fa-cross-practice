import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { Text, View, StyleSheet, Button, FlatList, TextInput } from 'react-native';
import React, { useState } from 'react';

 
const HomeScreen = ({ navigation }) => {
  const [name, setName] = useState('');  
  
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Главная</Text>
      <TextInput 
        style={styles.input}
        placeholder="Введите ваше имя"
        onChangeText={setName}
      />
      <Button
        title="Перейти к приветствию"
        onPress={() => navigation.navigate('Приветствие', { userName: name })}
      />
      <View style={styles.space} />
      <Button
        title="Детали"
        onPress={() => navigation.navigate('Детали')}
      />
      <View style={styles.space} />
      <Button
        title="Контакты"
        onPress={() => navigation.navigate('Контакты')}
      />
    </View>
  );
};

const GreetingScreen = ({ route, navigation }) => {
  const { userName } = route.params; // Получение имени из маршрута

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Привет, {userName}!</Text>
      <Button title="Назад" onPress={() => navigation.goBack()} />
    </View>
  );
};


const DetailsScreen = ({ navigation }) => {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Детали</Text>
      <Button title="Назад" onPress={() => navigation.goBack()} />
    </View>
  );
};

const ContactsScreen = () => {
  const contacts = [
    { id: '1', name: 'Пупкин П. П.', phone: '123-456-7890' },
    { id: '2', name: 'Стулкин С. С.', phone: '987-654-3210' },
  ];

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Контакты</Text>
      <FlatList
        data={contacts}
        renderItem={({ item }) => (
          <View style={styles.contact}>
            <Text style={styles.contactName}>{item.name}</Text>
            <Text style={styles.contactPhone}>{item.phone}</Text>
          </View>
        )}
        keyExtractor={(item) => item.id} 
      />
    </View>
  );
};

const Stack = createNativeStackNavigator();

const App = () => {
  return (
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen name="Главная" component={HomeScreen} />
        <Stack.Screen name="Приветствие" component={GreetingScreen} />
        <Stack.Screen name="Детали" component={DetailsScreen} />
        <Stack.Screen name="Контакты" component={ContactsScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
};

export default App;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: {
    fontSize: 24,
    marginBottom: 20,
  },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    padding: 10,
    width: '80%',
    marginBottom: 20,
  },
  contact: {
    padding: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#ccc',
    width: '100%',
  },
  contactName: {
    fontWeight: 'bold',
  },
  contactPhone: {
    color: 'gray',
  },
  space: {
    width: 20, 
    height: 20,
  },
});
