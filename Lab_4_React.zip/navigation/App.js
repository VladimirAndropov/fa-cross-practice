import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { Text, View, StyleSheet, Button, FlatList } from 'react-native';
 
const HomeScreen = ({ navigation }) => {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Главная</Text>
      <Button
        title="Детали"
        onPress={() => navigation.navigate('Details')}
      />
      <View style={styles.space} />
      <Button
        title="Контакты"
        onPress={() => navigation.navigate('Contacts')}
      />
    </View>
  );
};

const DetailsScreen = ({ navigation }) => {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Детали</Text>
      <Button title="Назад" onPress={() => navigation.goBack()} />
    </View>
  );
};

const ContactsScreen = () => {
  const contacts = [
    { id: '1', name: 'Иванов П.П.', phone: '123-456-7890' },
    { id: '2', name: 'Сидоров А. А.', phone: '987-654-3210' },
  ];

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Контакты</Text>
      <FlatList
        data={contacts}
        renderItem={({ item }) => (
          <View style={styles.contact}>
            <Text style={styles.contactName}>{item.name}</Text>
            <Text style={styles.contactPhone}>{item.phone}</Text>
          </View>
        )}
        keyExtractor={(item) => item.id} 
      />
    </View>
  );
};

const Stack = createNativeStackNavigator();

const App = () => {
  return (
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen name="Home" component={HomeScreen} />
        <Stack.Screen name="Details" component={DetailsScreen} />
        <Stack.Screen name="Contacts" component={ContactsScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
};

export default App; 

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: {
    fontSize: 24,
    marginBottom: 20,
  },
  contact: {
    padding: 10,  
    borderBottomWidth: 1,
    borderBottomColor: '#ccc',
    width: '100%', 
  },
  contactName: {
    fontWeight: 'bold',
  },
  contactPhone: {
    color: 'gray',
  },
  space: {
    width: 20, 
    height: 20,
  },
});
