import { Text, SafeAreaView, StyleSheet } from 'react-native';
import { Card } from 'react-native-paper';
import AssetExample from './components/AssetExample';

const HelloWorld = () => {
  return (
    <Text style={styles.helloWorld}>Hello World</Text>
  );
};

export default function App() {
  return (
    <SafeAreaView style={styles.container}>
      
     
        <HelloWorld /> 
    
    </SafeAreaView>
  );
}

// Стиль для всех компонентов
const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#ecf0f1',
    padding: 8,
  },

  helloWorld: {
    fontSize: 24,
    textAlign: 'center',
    marginBottom: 16,
  },
});