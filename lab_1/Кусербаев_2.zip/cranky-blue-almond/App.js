import React from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';

const BookHighlight = () => {
  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.title}>5 книжных новинок октября</Text>
      <View style={styles.bookInfo}>
        <Text style={styles.bookTitle}>«Кадиш.com» Натан Ингландер.</Text>
        <Text style={styles.publisher}>Издательство «Книжники»</Text>
      </View>
      <Text style={styles.description}>
        Ироничная новелла Натана Ингландера, две личные истории культовой Патти Смит, репортаж британской журналистки о будущем человечества, дебютный роман Оушена Вуонга и журналистское расследование о создании «Моссада». В нашей подборке рассказываем о пяти захватывающих книжных новинках, которые достойны того, чтобы появиться на ваших полках.
      </Text>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
    backgroundColor: '#f0f0f0',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
  },
  bookInfo: {
    backgroundColor: '#d3d3d3',
    padding: 20,
    marginBottom: 20,
    width: '100%',
    alignItems: 'center',
  },
  bookTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  publisher: {
    fontSize: 16,
    marginBottom: 10,
    textAlign: 'center',
  },
  description: {
    fontSize: 16,
    color: '#333',
    textAlign: 'center',
  },
});

export default BookHighlight;
