import React, { useState } from 'react';
import { StyleSheet, Text, View, Image, Button, TextInput, TouchableOpacity } from 'react-native';

export default function App() {
  const [name, setName] = useState('');

  const handlePress = () => {
    alert(`Привет, ${name || 'гость'}!`);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Добро пожаловать в моё приложение!</Text>
      
      {/* Добавленное место для картинки */}
      <Image
        source={{ uri: 'https://i.pinimg.com/564x/5d/10/28/5d10286a60b3b79c34928fde1aa83eee.jpg' }}
        style={styles.image}
      />
      
      <Text style={styles.subtitle}>Введите ваше имя:</Text>
      <TextInput
        style={styles.input}
        placeholder="Ваше имя"
        onChangeText={text => setName(text)}
        value={name}
      />
      
      <TouchableOpacity style={styles.button} onPress={handlePress}>
        <Text style={styles.buttonText}>Поздороваться</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f7f7f7',
    alignItems: 'center',
    paddingTop: 80,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    marginBottom: 20,
    color: '#333',
  },
  subtitle: {
    fontSize: 18,
    marginVertical: 15,
    color: '#555',
  },
  image: {
    width: '90%',
    height: 200,
    borderRadius: 15,
  },
  input: {
    height: 50,
    borderColor: '#8e8e8e',
    borderWidth: 1,
    width: '80%',
    borderRadius: 10,
    paddingHorizontal: 15,
    fontSize: 16,
    backgroundColor: '#fff',
  },
  button: {
    backgroundColor: '#4287f5',
    paddingVertical: 15,
    paddingHorizontal: 30,
    borderRadius: 10,
    marginTop: 25,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
  },
});