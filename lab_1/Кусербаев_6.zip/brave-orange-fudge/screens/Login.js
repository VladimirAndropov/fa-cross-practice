// screens/Login.js

import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  StyleSheet,
  TouchableOpacity,
  Image,
  Alert,
} from 'react-native';

import { Ionicons } from '@expo/vector-icons';

const Login = ({ navigation }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = () => {
    // Здесь можно добавить логику авторизации
    Alert.alert('Авторизация', 'Авторизация прошла успешно');
  };

  return (
    <View style={styles.container}>
      <Image source={require('../assets/snack-icon.png')} style={styles.logo} />

      <Text style={styles.title}>Авторизация</Text>

      <View style={styles.inputContainer}>
        <Ionicons name="mail-outline" size={24} color="#666" />
        <TextInput
          style={styles.input}
          placeholder="Email"
          placeholderTextColor="#666"
          keyboardType="email-address"
          autoCapitalize="none"
          onChangeText={(text) => setEmail(text)}
        />
      </View>

      <View style={styles.inputContainer}>
        <Ionicons name="lock-closed-outline" size={24} color="#666" />
        <TextInput
          style={styles.input}
          placeholder="Пароль"
          placeholderTextColor="#666"
          secureTextEntry
          onChangeText={(text) => setPassword(text)}
        />
      </View>

      <TouchableOpacity style={styles.button} onPress={handleLogin}>
        <Text style={styles.buttonText}>Войти</Text>
      </TouchableOpacity>

      <View style={styles.registerContainer}>
        <Text style={styles.registerText}>Нет аккаунта?</Text>
        <TouchableOpacity onPress={() => navigation.navigate('Register')}>
          <Text style={styles.registerButton}>Зарегистрироваться</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

export default Login;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    paddingHorizontal: 20,
    justifyContent: 'center',
  },
  logo: {
    alignSelf: 'center',
    marginBottom: 30,
    width: 120,
    height: 120,
  },
  title: {
    fontSize: 28,
    fontFamily: 'OpenSans-Bold',
    color: '#333',
    marginBottom: 30,
    alignSelf: 'center',
  },
  inputContainer: {
    flexDirection: 'row',
    borderBottomWidth: 1,
    borderBottomColor: '#666',
    paddingBottom: 8,
    marginBottom: 25,
    alignItems: 'center',
  },
  input: {
    flex: 1,
    paddingLeft: 10,
    fontSize: 18,
    color: '#333',
    fontFamily: 'OpenSans-Regular',
  },
  button: {
    backgroundColor: '#4287f5',
    paddingVertical: 15,
    borderRadius: 10,
    marginTop: 10,
  },
  buttonText: {
    color: '#fff',
    fontSize: 18,
    fontFamily: 'OpenSans-Bold',
    alignSelf: 'center',
  },
  registerContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginTop: 25,
  },
  registerText: {
    color: '#666',
    fontSize: 16,
    fontFamily: 'OpenSans-Regular',
  },
  registerButton: {
    color: '#4287f5',
    fontSize: 16,
    fontFamily: 'OpenSans-Bold',
    marginLeft: 5,
  },
});