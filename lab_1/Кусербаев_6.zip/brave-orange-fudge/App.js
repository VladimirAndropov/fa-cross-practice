// App.js

import React, { useEffect, useState } from 'react';
import { View, ActivityIndicator } from 'react-native';

import AppNavigation from './navigation/AppNavigation';

// Импортируем шрифты через expo-font
import * as Font from 'expo-font';
import AppLoading from 'expo-app-loading';

export default function App() {
  // Состояние загрузки шрифтов
  const [fontsLoaded, setFontsLoaded] = useState(false);

  // Загрузка шрифтов
  const loadFonts = async () => {
    await Font.loadAsync({
     
    });
  };

  if (!fontsLoaded) {
    return (
      <AppLoading
        startAsync={loadFonts}
        onFinish={() => setFontsLoaded(true)}
        onError={console.warn}
      />
    );
  }

  return <AppNavigation />;
}