// screens/ThirdScreen.js

import React, { useState } from 'react';
import { View, Text, Button, StyleSheet, TextInput } from 'react-native';

const ThirdScreen = ({ navigation }) => {
  const [name, setName] = useState('');

  const addContact = () => {
    // Здесь вы можете добавить логику для сохранения нового контакта
    alert(`Контакт ${name} добавлен!`);
    navigation.popToTop();
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Добавить новый контакт</Text>
      <TextInput
        style={styles.input}
        placeholder="Имя контакта"
        value={name}
        onChangeText={setName}
      />
      <Button title="Сохранить" onPress={addContact} />
    </View>
  );
};

export default ThirdScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    justifyContent: 'center',
    backgroundColor: '#fff',
  },
  title: {
    fontSize: 28,
    marginBottom: 20,
    alignSelf: 'center',
  },
  input: {
    height: 50,
    borderColor: '#8e8e8e',
    borderWidth: 1,
    borderRadius: 10,
    paddingHorizontal: 15,
    fontSize: 18,
    marginBottom: 20,
  },
});