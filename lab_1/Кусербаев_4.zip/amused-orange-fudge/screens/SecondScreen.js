// screens/SecondScreen.js

import React from 'react';
import { View, Text, Button, StyleSheet } from 'react-native';

const SecondScreen = ({ route, navigation }) => {
  const { contact } = route.params;

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Детали контакта</Text>
      <Text style={styles.contactName}>{contact.name}</Text>
      <Button title="Назад" onPress={() => navigation.goBack()} />
    </View>
  );
};

export default SecondScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
  },
  title: {
    fontSize: 28,
    marginBottom: 20,
  },
  contactName: {
    fontSize: 24,
    marginBottom: 20,
  },
});