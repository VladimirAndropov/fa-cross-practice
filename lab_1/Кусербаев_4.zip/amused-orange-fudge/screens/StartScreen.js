// screens/StartScreen.js

import React from 'react';
import { View, Text, Button, StyleSheet, FlatList, TouchableOpacity } from 'react-native';

const contacts = [
  { id: '1', name: 'Иван Иванов' },
  { id: '2', name: 'Петр Петров' },
  { id: '3', name: 'Сидоров Сергей' },
];

const StartScreen = ({ navigation }) => {
  const renderItem = ({ item }) => (
    <TouchableOpacity onPress={() => navigation.navigate('Second', { contact: item })}>
      <Text style={styles.item}>{item.name}</Text>
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Контакты</Text>
      <FlatList
        data={contacts}
        renderItem={renderItem}
        keyExtractor={(item) => item.id}
      />
      <Button title="Добавить контакт" onPress={() => navigation.navigate('Third')} />
    </View>
  );
};

export default StartScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#fff',
  },
  title: {
    fontSize: 28,
    marginBottom: 20,
    alignSelf: 'center',
  },
  item: {
    fontSize: 20,
    padding: 10,
    borderBottomColor: '#ccc',
    borderBottomWidth: 1,
  },
});