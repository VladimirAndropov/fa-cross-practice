// App.js

import * as React from 'react';

import { NavigationContainer } from '@react-navigation/native';

// Импортируем необходимые функции
import { createDrawerNavigator } from '@react-navigation/drawer';

import StartScreen from './screens/StartScreen';
import SecondScreen from './screens/SecondScreen';
import ThirdScreen from './screens/ThirdScreen';

const Drawer = createDrawerNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Drawer.Navigator initialRouteName="Start">
        <Drawer.Screen name="Start" component={StartScreen} options={{ title: 'Контакты' }} />
        <Drawer.Screen name="Second" component={SecondScreen} options={{ title: 'Детали контакта' }} />
        <Drawer.Screen name="Third" component={ThirdScreen} options={{ title: 'Добавить контакт' }} />
      </Drawer.Navigator>
    </NavigationContainer>
  );
}