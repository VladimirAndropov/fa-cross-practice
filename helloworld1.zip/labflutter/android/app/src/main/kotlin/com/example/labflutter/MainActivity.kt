package com.example.labflutter

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
