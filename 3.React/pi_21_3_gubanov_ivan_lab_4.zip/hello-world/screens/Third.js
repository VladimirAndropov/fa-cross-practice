import { useNavigation } from '@react-navigation/native';
import { Button } from 'react-native';

const Third = () => {
  const navigation = useNavigation();
  return (
    <Button title="Go to Second Screen" onPress={() => navigation.navigate('Second')} />
  );
};

export default Third