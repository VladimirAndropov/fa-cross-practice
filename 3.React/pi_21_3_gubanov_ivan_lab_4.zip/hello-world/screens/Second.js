import React from 'react'
import { useNavigation } from '@react-navigation/native';
import { Button} from 'react-native'

const Second = () => {
  const navigation = useNavigation();
  return (
    <>
      <Button title="Go to Third Screen" styleonPress={() => navigation.navigate('Third')} />
      <Button title="Go to Start Screen" onPress={() => navigation.navigate('Start')} />
    </>
  );
};

export default Second