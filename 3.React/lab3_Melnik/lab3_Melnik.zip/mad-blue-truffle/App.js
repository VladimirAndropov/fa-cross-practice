import React from 'react';
import { View, Text, Image, ScrollView, StyleSheet, TouchableOpacity, Dimensions } from 'react-native';

const { width, height } = Dimensions.get('window');

const Slide = ({ imageSource, title, description }) => (
  <View style={styles.slide}>
    <Image source={{ uri: imageSource }} style={styles.image} />
    <Text style={styles.title}>{title}</Text>
    <Text style={styles.description}>{description}</Text>
  </View>
);

const App = () => {
  return (
    <View style={styles.container}>
      <ScrollView horizontal pagingEnabled showsHorizontalScrollIndicator={false}>
        <Slide
          imageSource="https://is5-ssl.mzstatic.com/image/thumb/Purple114/v4/dc/79/db/dc79db10-11b0-0d13-9709-d6408f34ac85/AppIcon-0-0-1x_U007emarketing-0-0-0-4-0-0-sRGB-0-0-0-GLES2_U002c0-512MB-85-220-0-0.png/1200x630wa.png"
          title="Get the best prices"
          description="Add the destinations you like to your Favorites. Yandex.Flights will notify you when prices change."
        />
        <Slide
          imageSource="https://image.winudf.com/v2/image1/Y29tLnRzZWwudGVsa29tc2Vsa3Vfc2NyZWVuXzNfMTYzOTczMTYxMV8wMzk/screen-3.jpg?fakeurl=1&type=.jpg"
          title="Stay informed"
          description="Yandex.Flights will inform you via push notifications if your flight is delayed or cancelled."
        />
        <Slide
          imageSource="https://class-tour.com/wp-content/uploads/5/0/4/5040c9ec030e7241a3565ad2c23a0b2e.png"
          title="Track your flights"
          description="Keep track of your flight status and receive real-time updates."
        />
      </ScrollView>

      <View style={styles.pagination}>
        <View style={styles.dot} />
        <View style={styles.dot} />
        <View style={[styles.dot, styles.dotActive]} />
      </View>

      <TouchableOpacity style={styles.button}>
        <Text style={styles.buttonText}>Got it, thanks</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'flex-end', 
    alignItems: 'center',
    backgroundColor: '#fff',
  },
  slide: {
    width: width,
    height: height * 0.6, 
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  image: {
    width: 200,
    height: 200,
    marginBottom: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 10,
  },
  description: {
    fontSize: 16,
    textAlign: 'center',
    color: '#555',
    marginBottom: 20,
  },
  pagination: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 20,
  },
  dot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#ccc',
    marginHorizontal: 4,
  },
  dotActive: {
    backgroundColor: '#000',
  },
  button: {
    backgroundColor: '#ffd700',
    paddingVertical: 15,
    paddingHorizontal: 50,
    borderRadius: 30,
    marginBottom: 40,
  },
  buttonText: {
    color: '#000',
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export default App;
