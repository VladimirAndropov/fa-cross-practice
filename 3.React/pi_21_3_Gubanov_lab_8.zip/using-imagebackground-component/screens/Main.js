import { useNavigation } from '@react-navigation/native';
import { Button, Text } from 'react-native';

const Main = ({route}) => {
  const navigation = useNavigation();
  return (
    <>
      <Button title="Выйти" onPress={() => navigation.navigate('Auth')}/>
      <Text>
        Привет, {route.params.paramKey}
      </Text>
    </>
  );
};

export default Main