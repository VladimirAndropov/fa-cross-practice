import { useNavigation } from '@react-navigation/native';
import { Button, Text, TextInput, View, SafeAreaView } from 'react-native';
import React, {useState} from 'react';

const Auth = () => {

  const [userName, setUserName] = useState('');

  const navigation = useNavigation();
  return (
    <SafeAreaView style={{flex: 1}}>
      <View>
        { userName === '' ?
          <Button title="Авторизоваться" onPress={() => navigation.navigate('Main')} disabled={true} />
          :
          <Button
            title="Авторизоваться"
            onPress={() => navigation.navigate('Main', {
                paramKey: userName,
              })
            }
          />
        }
        <Text>
            Введите своё имя
        </Text>
        <TextInput
          value={userName}
          onChangeText={(username) => setUserName(username)}
          placeholder={'Имя'}
        />
      </View>
    </SafeAreaView>
  );
};

export default Auth