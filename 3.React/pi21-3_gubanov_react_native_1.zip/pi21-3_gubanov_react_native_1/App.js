import { Text, SafeAreaView, StyleSheet, Image } from 'react-native';

// You can import supported modules from npm
import { Card } from 'react-native-paper';

// or any files within the Snack
import AssetExample from './components/AssetExample';

export default function App() {
  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.paragraph}>
        Журнал Bright
      </Text>
      <Card style={{ padding: 10 }}>
        <Text style={styles.link}>Новости</Text>
        <Image
          style={styles.image}
          source={require('./assets/subway.jpg')}
        />
        <Text style={styles.textTitle}>
          Путин и Собянин открыли первый участок новой Троицкой линии метро
        </Text>
        <Text style={styles.textDisc}>
          В составе новой линии работают станции «Новаторская» (пересадка на Большую кольцевую), «Университет   дружбы народов», «Генерала Тюленева» и «Тютчевская». Теперь более 800 тысяч человек получили метро в пешей доступности.
        </Text>
      </Card>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  paragraph: {
    margin: 24,
    fontSize: 25,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  link: {
    color: 'blue',
    marginTop: 10,
    marginBottom: 30,
    fontSize: 20
  },
  textTitle: {
    fontSize: 20,
    fontWeight: 'bold'
  },
  textDisc: {
    fontSize: 15
  },
  image: {
    width: '90%',
    height: 200, 
    resizeMode: 'cover'
  }
});
