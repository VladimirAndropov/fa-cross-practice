import React from 'react';
import { StyleSheet, Text, View, Button, Image } from 'react-native';

const LotsOfStyles = () => {
    return (
        <View style={styles.container}>
            <Text style={styles.header}>Журнал Bright</Text>
            
            <View style={styles.contentContainer}>
                <Text style={styles.sectionTitle}>Новости</Text>
                <Image
                    source={{ uri: 'https://www.leadsmarttech.com/wp-content/uploads/LeadSmart-hero-2.jpg' }}
                    style={styles.image}
                />
                <Text style={styles.bigblack}>Технологии будущего уже сегодня</Text>
                <Text style={styles.smallblack}>
                    Как инновации меняют наш мир. Развитие технологий движется с ошеломляющей скоростью. Мы постоянно сталкиваемся с новыми изобретениями, которые делают нашу жизнь проще.
                </Text>
                <Text style={styles.smallblack}>
                    Умные дома, искусственный интеллект и виртуальная реальность — всё это уже не фантастика, а реальность сегодняшнего дня.
                </Text>
                <Button title="Читать далее" onPress={() => { alert('Читать далее!'); }} />
            </View>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        marginTop: 50,
        padding: 20,
    },
    header: {
        fontSize: 24,
        fontWeight: 'bold',
        textAlign: 'center',
        marginBottom: 20,
    },
    contentContainer: {
        backgroundColor: '#f0f0f0',
        padding: 15,
        borderRadius: 10,
    },
    sectionTitle: {
        fontSize: 18,
        color: 'blue',
        marginBottom: 10,
    },
    image: {
        width: '100%',
        height: 200,
        marginBottom: 10,
    },
    bigblack: {
        color: 'black',
        fontSize: 24,
        fontWeight: 'bold',
        marginBottom: 5,
    },
    smallblack: {
        color: 'black',
        fontSize: 16,
        marginBottom: 5,
    },
    blue: {
        color: 'blue',
        fontSize: 16,
        marginBottom: 5,
    },
});

export default LotsOfStyles;
