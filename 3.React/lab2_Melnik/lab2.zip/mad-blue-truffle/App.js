import React from 'react';
import { View, Text, Button, StyleSheet, Alert } from 'react-native';

const App = () => {
  const readMore = () => {
    Alert.alert("Читать далее", "Здесь будет больше текста для чтения.");
  };

  return (
    <View style={styles.container}>
      <Text style={styles.header}>5 книжных новинок октября</Text>
      
      <View style={styles.card}>
        <Text style={styles.title}>«Кадиш.com» Натан Ингландер.</Text>
        <Text style={styles.subtitle}>Издательство «Книжники»</Text>
        <View style={styles.divider} />

        <Text style={styles.description}>
          Ироничная новелла Натана Ингландера, две личные истории культовой Патти Смит, репортаж британской журналистки о будущем человечества, дебютный роман Оушена Вуона и журналистское расследование о создании «Моссада». В нашей подборке рассказываем о пяти захватывающих книжных новинках, которые достойны того, чтобы появиться на ваших полках.
        </Text>
        
        <Button title="Читать далее" onPress={readMore} color="#007AFF" />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f0f0f0',
    padding: 20,
  },
  header: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  card: {
    width: '100%',
    backgroundColor: '#e0e0e0',
    padding: 20,
    borderRadius: 10,
    alignItems: 'center',
  },
  title: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  subtitle: {
    fontSize: 14,
    marginVertical: 10,
  },
  divider: {
    width: '100%',
    height: 1,
    backgroundColor: '#b0b0b0',
    marginVertical: 10,
  },
  description: {
    fontSize: 14,
    textAlign: 'center',
    marginBottom: 20,
  },
});

export default App;
