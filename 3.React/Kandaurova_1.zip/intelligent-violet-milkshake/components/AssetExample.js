import { Text, View, StyleSheet, Image, Link } from 'react-native';

export default function AssetExample() {
  return (
    <View style={styles.container}>
    <Image style={styles.logo} source={require('../assets/react_photo.png')} />
      <Text style={styles.paragraph}>
        Мотивацию в студию: поддерживающие фразы для этой осени
      </Text>
      <Text style={styles.paragraph2}>
        Все мы время от времени нуждаемся в поддержке и мотивации, именно поэтому психологи советуют держать перед глазами важные для вас фразы. Это может быть записка на холодильнике или над рабочим столом, заставка на экране телефона или ноутбука, надпись на обложке любимого блокнота. Казалось бы мелочь, однако маленькие мотивационные напоминания мозгу очень даже нужны. 
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 24,
    margin: 10,
    backgroundColor: "pink",
    borderRadius: 20
  },
  paragraph: {
    margin: 24,
    marginTop: 20,
    fontSize: 26,
    fontWeight: 'bold',
    textAlign: 'center',
    alignItems: 'center',
    justifyContent: 'center',
    width: 300
  },
   paragraph2: {
    margin: 10,
    marginTop: 6,
    fontSize: 14,
    textAlign: 'center',
    alignItems: 'center',
    justifyContent: 'center',
    width: 300
  },
  logo: {
    height: 128,
    width: 128,
  }
});
