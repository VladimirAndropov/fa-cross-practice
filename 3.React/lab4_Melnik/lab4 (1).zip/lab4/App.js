import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { createDrawerNavigator } from '@react-navigation/drawer';
import Start from './screens/Start';
import Second from './screens/Second';
import Third from './screens/Third';

const Stack = createStackNavigator();
const Drawer = createDrawerNavigator();

function StackNavigator() {
  return (
    <Stack.Navigator initialRouteName="Start">
      <Stack.Screen name="Начало" component={Start} />
      <Stack.Screen name="два" component={Second} />
      <Stack.Screen name="три" component={Third} />
    </Stack.Navigator>
  );
}

export default function App() {
  return (
    <NavigationContainer>
      <Drawer.Navigator initialRouteName="Stack">
        <Drawer.Screen name="" component={StackNavigator} />
        <Drawer.Screen name="два" component={Second} />
        <Drawer.Screen name="три" component={Third} />
      </Drawer.Navigator>
    </NavigationContainer>
  );
}

