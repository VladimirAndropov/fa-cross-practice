import React, { useState } from 'react';
import { View, Text, Button, FlatList, TouchableOpacity } from 'react-native';

const Start = ({ navigation }) => {
  const [contacts, setContacts] = useState([
    { id: '1', name: 'Alice', phone: '+7 123 456 78 90' },
    { id: '2', name: 'Bob', phone: '+7 234 567 89 01' },
    { id: '3', name: 'Charlie', phone: '+7 345 678 90 12' },
  ]);

  const addContact = (newContact) => {
    setContacts((prevContacts) => [...prevContacts, newContact]);
  };

  return (
    <View>
      <Text>  </Text>
      <Text>Добро пожаловать в галерею контактов</Text>
      <FlatList
        data={contacts}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <TouchableOpacity onPress={() => navigation.navigate('два', { contact: item })}>
            <Text>  </Text>
            <Text>{item.name}</Text>
          </TouchableOpacity>
        )}
      />
      <Text>  </Text>
      <Button
        title="Добавить новый контакт"
        onPress={() => navigation.navigate('три', { addContact })}
      />
    </View>
  );
};

export default Start;
