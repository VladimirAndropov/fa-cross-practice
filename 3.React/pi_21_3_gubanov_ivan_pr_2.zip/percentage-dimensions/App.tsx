import React from 'react';
import {View, Text, StyleSheet} from 'react-native';

const PercentageDimensionsBasics = () => {
  return (
    <View style={{height: '100%', marginTop: 50}}>
      <View
        style={{
          height: '5%'
        }}
      >
        <Text style={styles.textCenterHeader}>
          5 книжных новинок октября
        </Text>
      </View>
      <View
        style={{
          height: '20%',
          backgroundColor: '#d4d2cd',
        }}
      >
        <Text style={styles.textCenter}>
          {'Кадиш.com Натан Ингландер\nИздательство книжники'}
        </Text>
      </View>
      <View
        style={{
          height: '75%',
          backgroundColor: '#82817d',
        }}
      >
        <Text style={styles.textBody}>
          {'Ироничная новелла Натана Ингландера,\nдве личные истории культовой Патти Смит\nрепортаж британской журналистки\nо будущем человечества'}
        </Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  textCenterHeader: {
    textAlign: 'center',
    fontWeight: 'bold',
    fontSize: 18
  },
  textCenter: {
    textAlign: 'center',
    fontSize: 16,
    marginTop: 20
  },
  textBody: {
    textAlign: 'center',
    fontSize: 14,
    marginTop: 20,
    color: 'white'
  }
})

export default PercentageDimensionsBasics;